package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.StringReader

/**
 * RAM PLAYER v21.0 EXTREME MASTER EDITION — Automated Unit Test Suite.
 *
 * Covers:
 * - Audio codec recognition, Hindi->English->Fallback track selection, missing/unsupported/decoder/output
 *   diagnostics, bounded recovery with cooldown, and AudioDelayProcessor 0ms bypass.
 * - Scoped NetworkClient headers (no host-wide leakage between channels, cross-host credential protection).
 * - Universal M3U/M3U8 relative URLs, KODIPROP/EXTVLCOPT/pipe headers, invalid entries, parse stats.
 * - Xtream Codes live URL generation based on server `allowed_output_formats` and preferences.
 * - Complete Category Delete, Individual Channel Delete, persistence via `deletionKey()`, profile isolation.
 * - 5-Second OK/ENTER Hold-to-Delete monotonic state machine (5s trigger, early release cancel,
 *   repeat-event guard, short tap vs configurable long press, ineligible/focus-loss cancel).
 * - 512MB / 1GB / 2GB / 4GB+ DeviceOptimizationProfile defaults, memory pressure & heap guards.
 * - PlaybackRecoveryEngine granular failure classification & M3U parsing throughput benchmark.
 */
class RamPlayerV21MasterTest {

    @Test
    fun audioTrackIntelligencePrioritizesHindiThenEnglishAndNeverSelectsUnsupported() {
        val tracks = listOf(
            AudioTrackDescriptor(0, 0, "hi", "Hindi Dolby", "audio/eac3", "ec-3", 6, 48000, 384000, isSupported = false, isSelected = false),
            AudioTrackDescriptor(0, 1, "en", "English AAC", "audio/mp4a-latm", "mp4a.40.2", 2, 48000, 128000, isSupported = true, isSelected = false),
            AudioTrackDescriptor(0, 2, "ta", "Tamil MP3", "audio/mpeg", "", 2, 44100, 128000, isSupported = true, isSelected = false)
        )
        // Hindi E-AC3 is unsupported -> must NOT select it; falls back to supported English AAC
        val best = AudioTrackIntelligenceEngine.selectBestAudioTrack(tracks, preferredLanguage = "hi")
        assertNotNull(best)
        assertEquals("en", best?.language)
        assertEquals("AAC", best?.shortCodecName())
        assertTrue(best?.isSupported == true)

        // When Hindi AAC IS supported, Hindi must win over English
        val withSupportedHindi = tracks + AudioTrackDescriptor(0, 3, "hin", "Hindi AAC", "audio/mp4a-latm", "mp4a.40.5", 2, 48000, 96000, isSupported = true, isSelected = false)
        val bestHindi = AudioTrackIntelligenceEngine.selectBestAudioTrack(withSupportedHindi, preferredLanguage = "hi")
        assertEquals("hin", bestHindi?.language)
        assertEquals("HE-AAC", bestHindi?.shortCodecName())
    }

    @Test
    fun audioDiagnosticsDistinguishesMissingUnsupportedDecoderAndOutputFailures() {
        val noAudio = AudioTrackIntelligenceEngine.diagnoseAudioState(emptyList())
        assertFalse(noAudio.audioDetected)
        assertEquals(AudioFailureReason.SOURCE_NO_AUDIO, noAudio.failureReason)
        assertEquals("NO AUDIO", noAudio.osdShortBadge())

        val unsupportedOnly = AudioTrackIntelligenceEngine.diagnoseAudioState(
            listOf(AudioTrackDescriptor(0, 0, "en", "Dolby", "audio/ac3", "ac-3", 6, 48000, 384000, isSupported = false, isSelected = false))
        )
        assertTrue(unsupportedOnly.audioDetected)
        assertEquals(0, unsupportedOnly.supportedTracks)
        assertEquals(AudioFailureReason.UNSUPPORTED_CODEC, unsupportedOnly.failureReason)

        val decoderErr = AudioTrackIntelligenceEngine.diagnoseAudioState(
            listOf(AudioTrackDescriptor(0, 0, "en", "AAC", "audio/mp4a-latm", "mp4a.40.2", 2, 48000, 128000, isSupported = true, isSelected = true)),
            decoderError = "MediaCodec init failed"
        )
        assertEquals(AudioFailureReason.DECODER_INIT_FAILED, decoderErr.failureReason)

        val outputErr = AudioTrackIntelligenceEngine.diagnoseAudioState(
            listOf(AudioTrackDescriptor(0, 0, "en", "PCM", "audio/raw", "", 2, 48000, 1536000, isSupported = true, isSelected = true)),
            outputError = "AudioTrack write failed"
        )
        assertEquals(AudioFailureReason.OUTPUT_ROUTING_ERROR, outputErr.failureReason)

        // Bounded recovery with cooldown
        assertTrue(AudioTrackIntelligenceEngine.shouldAttemptAudioRecovery(decoderErr, attemptsForChannel = 0, lastAttemptElapsedMs = 0L, nowElapsedMs = 5000L))
        assertFalse(AudioTrackIntelligenceEngine.shouldAttemptAudioRecovery(decoderErr, attemptsForChannel = 1, lastAttemptElapsedMs = 4000L, nowElapsedMs = 5000L))
        assertFalse(AudioTrackIntelligenceEngine.shouldAttemptAudioRecovery(decoderErr, attemptsForChannel = 2, lastAttemptElapsedMs = 0L, nowElapsedMs = 15000L))
    }

    @Test
    fun networkClientScopesHeadersPerChannelAndProtectsCrossHostCredentials() {
        NetworkClient.clearStreamHeaders()
        val chA = NetworkClient.extractCleanUrlAndRegisterHeaders(
            "https://provider.example/hls/chA/master.m3u8?token=aaa|User-Agent=AgentA&Referer=https://refA.example&Authorization=Bearer%20secretA&Cookie=sid=A"
        )
        val chB = "https://provider.example/hls/chB/master.m3u8?token=bbb"

        // Channel A gets its headers + its HLS child segment inherits them
        val hdrsA = NetworkClient.headersForUrl(chA)
        assertEquals("AgentA", hdrsA["User-Agent"])
        assertEquals("Bearer secretA", hdrsA["Authorization"])
        val segA = NetworkClient.headersForUrl("https://provider.example/hls/chA/seg001.ts")
        assertEquals("AgentA", segA["User-Agent"])

        // Channel B on the SAME provider host MUST NOT inherit Channel A's headers!
        val hdrsB = NetworkClient.headersForUrl(chB)
        assertTrue(hdrsB.isEmpty())

        // Cross-host redirect must NOT leak Authorization or Cookie, while preserving User-Agent/Referer
        NetworkClient.registerScopedDerivedUrl(chA, "https://cdn-other.example/edge/stream.m3u8")
        val crossHostHdrs = NetworkClient.headersForUrl("https://cdn-other.example/edge/stream.m3u8")
        assertEquals("AgentA", crossHostHdrs["User-Agent"])
        assertEquals("https://refA.example", crossHostHdrs["Referer"])
        assertNull(crossHostHdrs["Authorization"])
        assertNull(crossHostHdrs["Cookie"])
    }

    @Test
    fun m3uParserResolvesRelativeUrlsKodiPropsAndCollectsParseStats() {
        NetworkClient.clearStreamHeaders()
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="India" tvg-id="dd1",DD National HD
#KODIPROP:inputstream.adaptive.stream_headers=User-Agent=KodiUA&Referer=https://dd.example
channels/dd1/index.m3u8?auth=tok1
#EXTINF:-1 group-title="UK",BBC One
https://uk.example/bbc1.m3u8
#EXTINF:-1 group-title="UK",BBC One
https://uk.example/bbc1_backup.m3u8
#EXTINF:-1 group-title="UK",Duplicate URL
https://uk.example/bbc1.m3u8
not_a_valid_url_line
""".trimIndent()

        val stats = M3uParser.parseWithStats(
            reader = StringReader(playlist),
            baseUrl = "https://iptv.example/playlists/master.m3u"
        )
        assertEquals(2, stats.channels.size)
        assertEquals("https://iptv.example/playlists/channels/dd1/index.m3u8?auth=tok1", stats.channels[0].streamUrl)
        assertEquals("KodiUA", NetworkClient.headersForUrl(stats.channels[0].streamUrl)["User-Agent"])
        assertEquals("https://uk.example/bbc1_backup.m3u8", stats.channels[1].backupUrl)
        assertEquals(1, stats.duplicateUrlsSkipped)
        assertEquals(1, stats.mergedBackupCount)
        assertEquals(1, stats.invalidEntriesSkipped)
        assertEquals(1, stats.categoryCounts["India"])
        assertEquals(1, stats.categoryCounts["UK"])
    }

    @Test
    fun xtreamLiveUrlBuilderRespectsAllowedFormatsAndPreferences() {
        val repo = XtreamRepository()
        val (tsOnlyPrimary, tsOnlyBackup) = repo.buildLiveStreamUrls(
            cleanBase = "http://panel.example:8080/",
            username = "u1",
            password = "p1",
            streamId = "5001",
            allowedOutputFormats = listOf("ts"),
            preferredExtension = "auto"
        )
        assertEquals("http://panel.example:8080/live/u1/p1/5001.ts", tsOnlyPrimary)
        assertEquals("", tsOnlyBackup)

        val (bothPrimary, bothBackup) = repo.buildLiveStreamUrls(
            cleanBase = "http://panel.example:8080",
            username = "u1",
            password = "p1",
            streamId = "5002",
            allowedOutputFormats = listOf("m3u8", "ts"),
            preferredExtension = "auto"
        )
        assertEquals("http://panel.example:8080/live/u1/p1/5002.m3u8", bothPrimary)
        assertEquals("http://panel.example:8080/live/u1/p1/5002.ts", bothBackup)

        val (prefTsPrimary, prefTsBackup) = repo.buildLiveStreamUrls(
            cleanBase = "http://panel.example:8080",
            username = "u1",
            password = "p1",
            streamId = "5003",
            allowedOutputFormats = listOf("m3u8", "ts"),
            preferredExtension = "ts"
        )
        assertEquals("http://panel.example:8080/live/u1/p1/5003.ts", prefTsPrimary)
        assertEquals("http://panel.example:8080/live/u1/p1/5003.m3u8", prefTsBackup)
    }

    @Test
    fun channelAndCategorySoftDeleteFilterWorksAndPersistsAcrossRefresh() {
        val chIndia = Channel("id_1", 1, "Aaj Tak", "India", "https://cdn.example/aaj.m3u8?token=v1")
        val chUk1 = Channel("id_2", 2, "BBC One", "UK", "https://cdn.example/bbc1.m3u8")
        val chUk2 = Channel("id_3", 3, "ITV 1", "UK", "https://cdn.example/itv1.m3u8")
        val chSports = Channel("id_4", 4, "Star Sports", "Sports", "https://cdn.example/ss1.m3u8")
        val raw = listOf(chIndia, chUk1, chUk2, chSports)

        // Delete entire UK category + individual Aaj Tak channel
        val deletedCats = setOf("UK")
        val deletedKeys = setOf(chIndia.deletionKey())

        // Simulate playlist refresh where query token & channel ID changed
        val refreshedIndia = chIndia.copy(id = "id_999", number = 10, streamUrl = "https://cdn.example/aaj.m3u8?token=v2")
        val refreshedList = listOf(refreshedIndia, chUk1, chUk2, chSports)

        val activeAfterRefresh = ChannelDeletionFilter.filterActiveChannels(
            rawChannels = refreshedList,
            deletedCategories = deletedCats,
            deletedChannelKeys = deletedKeys
        )
        assertEquals(1, activeAfterRefresh.size)
        assertEquals("Star Sports", activeAfterRefresh.first().name)

        // Restore UK category -> UK channels reappear while deleted Aaj Tak stays deleted
        val afterRestoreUk = ChannelDeletionFilter.filterActiveChannels(
            rawChannels = refreshedList,
            deletedCategories = emptySet(),
            deletedChannelKeys = deletedKeys
        )
        assertEquals(3, afterRestoreUk.size)
        assertTrue(afterRestoreUk.any { it.category == "UK" })
        assertFalse(afterRestoreUk.any { it.name == "Aaj Tak" })
    }

    @Test
    fun fiveSecondOkHoldControllerHandlesFullHoldEarlyReleaseRepeatAndCancellation() {
        val ctrl = OkLongHoldDeleteController(thresholdMs = 5_000L)

        // 1. Full 5-second hold triggers confirmation EXACTLY ONCE (ignores repeats)
        assertTrue(ctrl.onKeyDown(23, repeatCount = 0, nowElapsedMs = 1000L, isEligibleLiveTv = true, channelId = "ch_5", channelName = "Star Sports", channelNumber = 5))
        assertTrue(ctrl.onKeyDown(23, repeatCount = 1, nowElapsedMs = 1500L, isEligibleLiveTv = true, channelId = "ch_5", channelName = "Star Sports", channelNumber = 5))
        val pMid = ctrl.pollProgress(3000L)
        assertTrue(pMid.isActive)
        assertTrue(pMid.showCountdownOverlay)
        assertFalse(pMid.justReachedThreshold)
        assertEquals(3, pMid.remainingSeconds)

        val pTrigger = ctrl.pollProgress(6000L)
        assertTrue(pTrigger.justReachedThreshold)
        assertEquals("ch_5", pTrigger.channelId)
        assertEquals(5, pTrigger.channelNumber)

        // Polling again at 6500ms must NOT trigger a second confirmation
        val pAfter = ctrl.pollProgress(6500L)
        assertFalse(pAfter.justReachedThreshold)
        assertEquals(OkLongHoldDeleteController.ReleaseOutcome.ALREADY_TRIGGERED, ctrl.onKeyUp(23, 6600L))

        // 2. Early release at 3.0s cancels cleanly
        assertTrue(ctrl.onKeyDown(66, repeatCount = 0, nowElapsedMs = 10_000L, isEligibleLiveTv = true, channelId = "ch_6", channelName = "News", channelNumber = 6))
        assertEquals(OkLongHoldDeleteController.ReleaseOutcome.CANCELLED_EARLY, ctrl.onKeyUp(66, 13_000L))
        assertFalse(ctrl.isHolding())

        // 3. Short tap (<600ms) vs configurable short long-press (1000ms)
        assertTrue(ctrl.onKeyDown(160, repeatCount = 0, nowElapsedMs = 20_000L, isEligibleLiveTv = true, channelId = "ch_7", channelName = "Music", channelNumber = 7))
        assertEquals(OkLongHoldDeleteController.ReleaseOutcome.SHORT_TAP, ctrl.onKeyUp(160, 20_250L))

        assertTrue(ctrl.onKeyDown(23, repeatCount = 0, nowElapsedMs = 30_000L, isEligibleLiveTv = true, channelId = "ch_7", channelName = "Music", channelNumber = 7))
        assertEquals(OkLongHoldDeleteController.ReleaseOutcome.CONFIGURABLE_LONG_PRESS, ctrl.onKeyUp(23, 31_000L))

        // 4. Focus loss cancels active hold
        assertTrue(ctrl.onKeyDown(23, repeatCount = 0, nowElapsedMs = 40_000L, isEligibleLiveTv = true, channelId = "ch_8", channelName = "Kids", channelNumber = 8))
        ctrl.cancel()
        assertFalse(ctrl.isHolding())
        assertEquals(OkLongHoldDeleteController.ReleaseOutcome.IGNORED, ctrl.onKeyUp(23, 45_500L))
    }

    @Test
    fun deviceOptimizationProfilesExpiredTokensAndFailureClassifierWorkCorrectly() {
        val p512 = DeviceOptimizationProfile.resolve(PerformanceMode.AUTO_ADAPTIVE, totalRamMb = 512L, isLowRamDevice = true)
        assertEquals(PerformanceMode.LOW_MEMORY, p512.mode)
        assertEquals(128 * 1024, p512.ramPreloadBudgetBytes)

        val p2gb = DeviceOptimizationProfile.resolve(PerformanceMode.AUTO_ADAPTIVE, totalRamMb = 2048L, isLowRamDevice = false)
        assertEquals(PerformanceMode.SMART_BALANCED, p2gb.mode)
        assertEquals(256 * 1024, p2gb.ramPreloadBudgetBytes)

        val p4gb = DeviceOptimizationProfile.resolve(PerformanceMode.AUTO_ADAPTIVE, totalRamMb = 4096L, isLowRamDevice = false)
        assertEquals(PerformanceMode.HIGH_PERFORMANCE_4GB, p4gb.mode)
        assertEquals(320 * 1024, p4gb.ramPreloadBudgetBytes)

        // Heap-limit guard overrides 4GB mode if JVM heap is constrained
        val heapGuarded = DeviceOptimizationProfile.resolve(PerformanceMode.HIGH_PERFORMANCE_4GB, totalRamMb = 4096L, isLowRamDevice = false, maxJvmHeapMb = 64L)
        assertEquals(PerformanceMode.LOW_MEMORY, heapGuarded.mode)

        // Expired token guard
        assertTrue(StreamPreFetcher.hasExpiredQueryToken("https://cdn.example/live.m3u8?exp=1600000000", nowEpochSec = 1_750_000_000L))
        assertFalse(StreamPreFetcher.hasExpiredQueryToken("https://cdn.example/live.m3u8?exp=1900000000", nowEpochSec = 1_750_000_000L))

        // Failure classification
        assertEquals(PlaybackFailureCategory.PROVIDER_AUTH_ERROR, PlaybackRecoveryEngine.classifyFailure(2004, "ERROR_CODE_IO_BAD_HTTP_STATUS", "Response code: 403", 403))
        assertEquals(PlaybackFailureCategory.LIVE_WINDOW_DRIFT, PlaybackRecoveryEngine.classifyFailure(1002, "ERROR_CODE_BEHIND_LIVE_WINDOW", "Behind live window"))
        assertEquals(PlaybackFailureCategory.DNS_ERROR, PlaybackRecoveryEngine.classifyFailure(2001, "ERROR_CODE_IO_NETWORK_CONNECTION_FAILED", "Unable to resolve host"))
        assertEquals(PlaybackFailureCategory.DECODER_INIT_FAILED, PlaybackRecoveryEngine.classifyFailure(4001, "ERROR_CODE_DECODER_INIT_FAILED", "Decoder init failed"))
        assertEquals(PlaybackFailureCategory.HLS_MANIFEST_ERROR, PlaybackRecoveryEngine.classifyFailure(3002, "ERROR_CODE_PARSING_MANIFEST_MALFORMED", "Input does not start with #EXTM3U"))
    }
}
