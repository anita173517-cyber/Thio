package com.harindra.iptvpro

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/**
 * Real-time PCM Audio Delay Processor for RAM PLAYER v21.0.
 *
 * CRITICAL AUDIO FIX (v21.0):
 * - When `targetDelayMs == 0`, returns [AudioProcessor.AudioFormat.NOT_SET] from [onConfigure]
 *   so ExoPlayer's DefaultAudioSink bypasses this processor completely without forcing PCM
 *   reconfiguration or breaking float/passthrough/offload audio paths.
 * - When delay > 0, supports both 16-bit PCM (`ENCODING_PCM_16BIT`) and 32-bit float PCM
 *   (`ENCODING_PCM_FLOAT`) with a bounded circular ring buffer safe on 512MB RAM Android TVs.
 * - Exposes genuine configured format diagnostics without faking PCM activity.
 */
@OptIn(UnstableApi::class)
class AudioDelayProcessor : BaseAudioProcessor() {

    companion object {
        const val MAX_DELAY_MS = 500
        private const val MAX_RING_BUFFER_BYTES = 512 * 1024 // Hard 512 KB cap for 512MB RAM TVs
    }

    @Volatile
    private var targetDelayMs: Int = 0

    @Volatile
    private var configuredSampleRate: Int = 0

    @Volatile
    private var configuredChannelCount: Int = 0

    @Volatile
    private var configuredEncoding: Int = C.ENCODING_INVALID

    private var bytesPerSample: Int = 2
    private var bytesPerMs: Int = 192 // default 48000 * 2 * 2 / 1000
    private var ringBuffer: ByteArray = ByteArray(1)
    private var writePos: Int = 0
    private var bufferedBytes: Int = 0
    private var configuredFormat: AudioProcessor.AudioFormat = AudioProcessor.AudioFormat.NOT_SET

    fun setDelayMs(delayMs: Int) {
        val clamped = delayMs.coerceIn(0, MAX_DELAY_MS)
        if (clamped != targetDelayMs) {
            targetDelayMs = clamped
            clearDelayBuffer()
        }
    }

    fun getDelayMs(): Int = targetDelayMs

    fun isPcmActive(): Boolean = configuredFormat != AudioProcessor.AudioFormat.NOT_SET

    fun getConfiguredSampleRate(): Int = configuredSampleRate

    fun getConfiguredChannelCount(): Int = configuredChannelCount

    fun getConfiguredEncoding(): Int = configuredEncoding

    @Synchronized
    fun clearDelayBuffer() {
        ringBuffer.fill(0)
        writePos = 0
        bufferedBytes = 0
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // Bypass cleanly when delay is 0ms so native audio sink / passthrough / float paths are untouched.
        if (targetDelayMs <= 0) {
            configuredFormat = AudioProcessor.AudioFormat.NOT_SET
            configuredSampleRate = inputAudioFormat.sampleRate
            configuredChannelCount = inputAudioFormat.channelCount
            configuredEncoding = inputAudioFormat.encoding
            return AudioProcessor.AudioFormat.NOT_SET
        }

        val sampleBytes = when (inputAudioFormat.encoding) {
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_FLOAT -> 4
            else -> {
                configuredFormat = AudioProcessor.AudioFormat.NOT_SET
                configuredSampleRate = inputAudioFormat.sampleRate
                configuredChannelCount = inputAudioFormat.channelCount
                configuredEncoding = inputAudioFormat.encoding
                return AudioProcessor.AudioFormat.NOT_SET
            }
        }

        configuredFormat = inputAudioFormat
        configuredSampleRate = inputAudioFormat.sampleRate
        configuredChannelCount = inputAudioFormat.channelCount
        configuredEncoding = inputAudioFormat.encoding
        bytesPerSample = sampleBytes

        val frameBytes = (inputAudioFormat.channelCount.coerceAtLeast(1)) * sampleBytes
        bytesPerMs = ((inputAudioFormat.sampleRate.toLong() * frameBytes) / 1000L).toInt().coerceAtLeast(frameBytes)
        val rawMaxBytes = (bytesPerMs.toLong() * MAX_DELAY_MS.toLong()).coerceAtMost(MAX_RING_BUFFER_BYTES.toLong()).toInt()
        val alignedMaxBytes = ((rawMaxBytes / frameBytes).coerceAtLeast(1)) * frameBytes

        if (ringBuffer.size != alignedMaxBytes) {
            ringBuffer = ByteArray(alignedMaxBytes)
        } else {
            ringBuffer.fill(0)
        }
        writePos = 0
        bufferedBytes = 0
        return inputAudioFormat
    }

    @Synchronized
    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining <= 0) return

        val delayMs = targetDelayMs
        if (delayMs <= 0 || ringBuffer.size <= 1 || configuredFormat == AudioProcessor.AudioFormat.NOT_SET) {
            val out = replaceOutputBuffer(remaining)
            out.put(inputBuffer)
            out.flip()
            return
        }

        val frameBytes = (configuredFormat.channelCount.coerceAtLeast(1)) * bytesPerSample
        val desiredDelayBytes = ((delayMs.toLong() * bytesPerMs.toLong()) / frameBytes.toLong()).toInt() * frameBytes
        val effectiveDelay = desiredDelayBytes.coerceIn(frameBytes, ringBuffer.size)

        val out = replaceOutputBuffer(remaining)
        val cap = ringBuffer.size
        for (i in 0 until remaining) {
            val incoming = inputBuffer.get()
            if (bufferedBytes < effectiveDelay) {
                ringBuffer[writePos] = incoming
                writePos = (writePos + 1) % cap
                bufferedBytes++
                out.put(0.toByte())
            } else {
                val readPos = (writePos - effectiveDelay + cap) % cap
                val delayedByte = ringBuffer[readPos]
                ringBuffer[writePos] = incoming
                writePos = (writePos + 1) % cap
                out.put(delayedByte)
            }
        }
        out.flip()
    }

    override fun onReset() {
        clearDelayBuffer()
        configuredFormat = AudioProcessor.AudioFormat.NOT_SET
        configuredSampleRate = 0
        configuredChannelCount = 0
        configuredEncoding = C.ENCODING_INVALID
    }
}
